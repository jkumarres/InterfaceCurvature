See "docs.pdf" for more information.
